import React from "react";

function Button({icon, text, altText, classStyle}) {
  return (
    <div className="flex bg-orange px-4 py-1 gap-2 rounded-full justify-center items-center text-white text-base font-semibold">
      <img src={icon} alt={altText} className={classStyle} />
      <span>{text}</span>
    </div>
  );
}

export default Button;
