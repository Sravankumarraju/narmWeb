import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, EffectFade } from 'swiper/modules';
import 'swiper/css';
import 'swiper/css/effect-fade';

const images = [
  '/slider-1.png',
  '/slider-2.png',
  '/slider-3.png',
  '/slider-4.png',
  '/slider-5.png',
];

const ImageSlider = () => {
  return (
    <div className="absolute inset-0 z-0">
      <Swiper
        modules={[Autoplay, EffectFade]}
        effect="fade"
        autoplay={{
          delay: 5000,
          disableOnInteraction: false,
        }}
        loop={true}
        className="h-full w-full"
      >
        {images.map((image, index) => (
          <SwiperSlide key={index}>
            <div 
              className="w-full h-full bg-cover bg-center"
              style={{
                backgroundImage: `url(${image})`,
              }}
            >
              <div className="absolute inset-0"></div>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default ImageSlider;