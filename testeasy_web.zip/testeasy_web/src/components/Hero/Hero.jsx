import React from 'react';
import { FaMicroscope } from 'react-icons/fa';
import ImageSlider from './ImageSlider';
import Button from '../Common/Button';

const Hero = () => {
  return (
    <div className="relative h-screen w-full overflow-hidden">
      <ImageSlider />
      <div className="relative z-10">
        <div className="container mx-auto px-16 py-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div>
                <img src="/logo.png" alt="Logo" className="" />
            </div>
            <div className='flex flex-col items-end md:flex-row'>
                <div className='flex'>
                    <img src="/FB.png" alt="FB Logo" className="w-8" />
                    <img src="/x.png" alt="X Logo" className="w-8" />
                    <img src="/insta.png" alt="Instagram Logo" className="w-8" />
                    <img src="/link.png" alt="Link Logo" className="w-8" />
                    <img src="/yt.png" alt="YT Logo" className="w-8" />

                </div>
                <div className='flex gap-2'>
                    {/* <div className='flex bg-orange px-4 py-1 gap-2 rounded-full justify-center items-center text-white text-base font-semibold'>
                        <img src="/call.png" alt="Call Logo" className="w-3" />
                        <span>+91 97437 02555</span>
                    </div> */}
                    <Button icon="/call.png" text="+91 97437 02555" altText="Call Icon" classStyle="w-3" />
                    <Button icon="/login.png" text="Login" altText="Login Icon" classStyle="w-6" />
                </div>
            </div>
            {/* <div className="md:w-1/2 mb-8 md:mb-0">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
                Fastest Growing Diagnostic Lab
              </h1>
              <p className="text-lg text-gray-200 mb-6">
                We are trusted healthcare companion to transform your health into wellness
              </p>
              <button className="bg-blue-600 text-white px-8 py-3 rounded-full hover:bg-blue-700 transition">
                Book Now
              </button>
            </div>
            <div className="md:w-1/2">
              <div className="bg-white bg-opacity-90 backdrop-blur-sm p-8 rounded-lg shadow-lg">
                <FaMicroscope className="text-6xl text-blue-600 mb-4" />
                <h3 className="text-2xl font-semibold mb-2">Advanced Lab Testing</h3>
                <p className="text-gray-600">
                  State-of-the-art facilities with accurate and timely results
                </p>
              </div>
            </div> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;