/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        orange: '#EB6408',      // Define a common orange color
        blue: '#114978',   // Define a common blue color
        white: '#FFFFFF',      // Define a common white color
        black : '#121212',
        yellow : '#FFF500',
        // customGray: {
        //   light: '#f7fafc',     // Nested shades of a custom color
        //   DEFAULT: '#a0aec0',   // Default shade
        //   dark: '#1a202c',
        // },
      },
    },
  },
  plugins: [],
}